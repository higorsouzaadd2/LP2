﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos2._0
{
    public partial class FrmExercício4 : Form
    {
        public FrmExercício4()
        {
            InitializeComponent();
        }

        private void FrmExercício4_Load(object sender, EventArgs e)
        {

        }

        private void btnContaNumero_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contaNum = 0;

            while (contador < rchtxtfrase.Text.Length)
            {
                if (char.IsNumber(rchtxtfrase.Text[contador]))
                {
                    contaNum++;
                }
                contador++;
            }
            MessageBox.Show($"o texto tem {contaNum} numeros");

        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            bool temEspaco = false;
            for (int i = 0; i < rchtxtfrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtfrase.Text[i]))
                {
                    MessageBox.Show($"a posição do 1º caracter branco é {i + 1}");
                    temEspaco = true;
                    break;
                }


            }
            if (!temEspaco)
            {
                MessageBox.Show("Nao há nenhum espaço em branco");
            }
        }
        

        private void btnContaLetras_Click(object sender, EventArgs e)
        {
            int contaLetras = 0;
            foreach (var c in rchtxtfrase.Text)
            {
                if (char.IsLetter(c))
                {
                  contaLetras++;  
                }
            }
            MessageBox.Show($"o texto tem {contaLetras} letras");
        }
    }
}
