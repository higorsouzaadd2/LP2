﻿namespace Pmetodos2._0
{
    partial class FrmExercício4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtfrase = new System.Windows.Forms.RichTextBox();
            this.btnContaNumero = new System.Windows.Forms.Button();
            this.btnEspacoBranco = new System.Windows.Forms.Button();
            this.btnContaLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtfrase
            // 
            this.rchtxtfrase.Location = new System.Drawing.Point(139, 51);
            this.rchtxtfrase.Name = "rchtxtfrase";
            this.rchtxtfrase.Size = new System.Drawing.Size(507, 160);
            this.rchtxtfrase.TabIndex = 0;
            this.rchtxtfrase.Text = "";
            // 
            // btnContaNumero
            // 
            this.btnContaNumero.Location = new System.Drawing.Point(139, 249);
            this.btnContaNumero.Name = "btnContaNumero";
            this.btnContaNumero.Size = new System.Drawing.Size(136, 66);
            this.btnContaNumero.TabIndex = 1;
            this.btnContaNumero.Text = "Conta Numero";
            this.btnContaNumero.UseVisualStyleBackColor = true;
            this.btnContaNumero.Click += new System.EventHandler(this.btnContaNumero_Click);
            // 
            // btnEspacoBranco
            // 
            this.btnEspacoBranco.Location = new System.Drawing.Point(307, 249);
            this.btnEspacoBranco.Name = "btnEspacoBranco";
            this.btnEspacoBranco.Size = new System.Drawing.Size(155, 66);
            this.btnEspacoBranco.TabIndex = 2;
            this.btnEspacoBranco.Text = "Posição 1º caracter branco";
            this.btnEspacoBranco.UseVisualStyleBackColor = true;
            this.btnEspacoBranco.Click += new System.EventHandler(this.btnEspacoBranco_Click);
            // 
            // btnContaLetras
            // 
            this.btnContaLetras.Location = new System.Drawing.Point(490, 249);
            this.btnContaLetras.Name = "btnContaLetras";
            this.btnContaLetras.Size = new System.Drawing.Size(156, 66);
            this.btnContaLetras.TabIndex = 3;
            this.btnContaLetras.Text = "Conta Letras";
            this.btnContaLetras.UseVisualStyleBackColor = true;
            this.btnContaLetras.Click += new System.EventHandler(this.btnContaLetras_Click);
            // 
            // FrmExercício4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnContaLetras);
            this.Controls.Add(this.btnEspacoBranco);
            this.Controls.Add(this.btnContaNumero);
            this.Controls.Add(this.rchtxtfrase);
            this.Name = "FrmExercício4";
            this.Text = "FrmExercício4";
            this.Load += new System.EventHandler(this.FrmExercício4_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtfrase;
        private System.Windows.Forms.Button btnContaNumero;
        private System.Windows.Forms.Button btnEspacoBranco;
        private System.Windows.Forms.Button btnContaLetras;
    }
}