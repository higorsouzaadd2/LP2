﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos2._0
{
    public partial class FrmExercício2 : Form
    {
        public FrmExercício2()
        {
            InitializeComponent();
        }

        private void btninserir2_Click(object sender, EventArgs e)
        {
            bool temerro = false;
            txtpalavra2.Text = "";
            if (string.IsNullOrEmpty(txtpalavra1.Text))
            {
                MessageBox.Show("Digite a palavra que deseja inserir os **");
                temerro = true;
            }
            if (temerro == false)
            {
                string txtOriginal = txtpalavra1.Text;
                int meio = txtOriginal.Length / 2;
                string resultado = txtOriginal.Insert(meio, "**");
                txtpalavra2.Text = resultado;
            }
        }

        private void btnverificar_Click(object sender, EventArgs e)
        {
            if (string.Compare(txtpalavra1.Text, txtpalavra2.Text) == 0)
            {
                MessageBox.Show("Os textos sao iguais");
            }
            else
            {
                MessageBox.Show("os textos sao diferentes");
            }
        }

        private void btninserir_Click(object sender, EventArgs e)
        {
            bool temerro = false;
            if (string.IsNullOrEmpty(txtpalavra1.Text))
            {
                MessageBox.Show("Digite o texto a ser inserido");
                temerro = true;
            }
            if (string.IsNullOrEmpty(txtpalavra2.Text))
            {
                MessageBox.Show("Digite o texto onde vai ser inserido");
                temerro = true;
            }

            if (temerro == false)
            {
                string textoDestino = txtpalavra2.Text;
                string textoInserir = txtpalavra1.Text;
                int meio = textoDestino.Length / 2;
                string parte1 = textoDestino.Substring(0, meio);
                string parte2 = textoDestino.Substring(meio);
                string resultado = parte1 + textoInserir + parte2;
                txtpalavra2.Text = resultado;
            }


        }
    }
    
}
