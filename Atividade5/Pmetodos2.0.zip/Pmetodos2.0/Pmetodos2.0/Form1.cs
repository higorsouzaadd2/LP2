﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos2._0
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Voce escolheu copiar");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Voce escolheu colar");
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (Application.OpenForms.OfType<FrmExercício2>().Count() > 0)
            {

                Application.OpenForms["FrmExercício2"].BringToFront();
            }

            else
            {
                FrmExercício2 frm_2 = new FrmExercício2();
                frm_2.MdiParent = this;
                frm_2.WindowState = FormWindowState.Maximized;
                frm_2.Show();
            }





        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercício3>().Count() > 0)
            {

                Application.OpenForms["FrmExercício3"].BringToFront();
            }

            else
            {
                FrmExercício3 frm_3 = new FrmExercício3();
                frm_3.MdiParent = this;
                frm_3.WindowState = FormWindowState.Maximized;
                frm_3.Show();
            }
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercício4>().Count() > 0)
            {

                Application.OpenForms["FrmExercício4"].BringToFront();
            }

            else
            {
                FrmExercício4 frm_4 = new FrmExercício4();
                frm_4.MdiParent = this;
                frm_4.WindowState = FormWindowState.Maximized;
                frm_4.Show();
            }
        }

        private void exercício5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercício5>().Count() > 0)
            {

                Application.OpenForms["FrmExercício5"].BringToFront();
            }

            else
            {
                FrmExercício5 frm_5 = new FrmExercício5();
                frm_5.MdiParent = this;
                frm_5.WindowState = FormWindowState.Maximized;
                frm_5.Show();
            }
        }
    }
}
