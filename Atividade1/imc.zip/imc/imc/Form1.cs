﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace imc
{
    public partial class Form1 : Form
    {
        Double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtaltura.Clear();
            txtpeso.Clear();
            txtimc.Clear();
        }

        private void txtpeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtpeso.Text, out peso)
                || (peso <= 0))
            {
                MessageBox.Show("Peso Invalido");
                txtaltura.Focus();
                           }
        }

        private void txtaltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtaltura.Text, out altura)
                || (altura <= 0))
            {
                MessageBox.Show("Altura Invalida");
                txtaltura.Focus();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            imc = peso / (altura * altura);
            imc = Math.Round(imc, 1);
            txtimc.Text = imc.ToString();
            

            if (imc < 18.5)
            {
                txtclassi.Text = "magreza";
                txtbeso.Text = "0";
            }
            else
                if (imc < 24.9)
            {
                txtclassi.Text = "Normal";
                txtbeso.Text = "0";
            }
            else
                if (imc < 29.9)
            {
                txtclassi.Text = "Sobrepeso";
                txtbeso.Text = "1";
            }
            else
                if (imc < 39.9)
            {
                txtclassi.Text = "obesidade";
                txtbeso.Text = "2";
            }
            else 
            {
                txtclassi.Text = "Obesidade grave";
                txtbeso.Text = "3";
            }

        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?",
                                "Saída", MessageBoxButtons.YesNo
                                , MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

       
        }
    }

