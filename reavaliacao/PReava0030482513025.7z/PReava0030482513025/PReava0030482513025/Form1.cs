﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PReava0030482513025
{
    public partial class Form1 : Form
    {
        double[] MatrizA = new double[10] { 1.50, 2.50, 3.50, 4.50, 5.50, 6.50, 7.50, 8.50, 9.50, 10.50 };
        double[] MatrizB = new double[10];
        int i;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {

            for (int i = 0; i < MatrizA.Length; i++ ) ;
            if (i % 2 == 0)
            {
               MatrizB[i] = MatrizA[i] + 4;
                i++;
            }
            if (!(i % 2 == 0)) 
            {
                MatrizB[i] = MatrizA[i] + 4;
                i++;
            }

            for (int i = 0; i < MatrizB.GetLength(0); i++)
            {

                lsbx1.Items.Add($"posiçao: {i}  MatrizA: {MatrizA[i].ToString()}  Matriz{MatrizB[i].ToString()}");
            }







        }

        private void lsbx1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lsbx1.Items.Remove("");
        }
    }
    
}
