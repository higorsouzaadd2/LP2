﻿namespace imc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btncalcular = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.txtimc = new System.Windows.Forms.TextBox();
            this.txtpeso = new System.Windows.Forms.MaskedTextBox();
            this.txtaltura = new System.Windows.Forms.MaskedTextBox();
            this.erropeso = new System.Windows.Forms.ErrorProvider(this.components);
            this.erroaltura = new System.Windows.Forms.ErrorProvider(this.components);
            this.txtclassi = new System.Windows.Forms.MaskedTextBox();
            this.txtbeso = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.erropeso)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erroaltura)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(177, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Peso Atual";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(177, 166);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Altura";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(177, 215);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "IMC";
            // 
            // btncalcular
            // 
            this.btncalcular.Location = new System.Drawing.Point(181, 283);
            this.btncalcular.Name = "btncalcular";
            this.btncalcular.Size = new System.Drawing.Size(75, 34);
            this.btncalcular.TabIndex = 3;
            this.btncalcular.Text = "Calcular";
            this.btncalcular.UseVisualStyleBackColor = true;
            this.btncalcular.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(324, 283);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(75, 34);
            this.btnlimpar.TabIndex = 4;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // btnsair
            // 
            this.btnsair.Location = new System.Drawing.Point(461, 283);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(75, 34);
            this.btnsair.TabIndex = 5;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = true;
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // txtimc
            // 
            this.txtimc.Enabled = false;
            this.txtimc.Location = new System.Drawing.Point(299, 215);
            this.txtimc.Name = "txtimc";
            this.txtimc.Size = new System.Drawing.Size(100, 26);
            this.txtimc.TabIndex = 8;
            // 
            // txtpeso
            // 
            this.txtpeso.Location = new System.Drawing.Point(299, 110);
            this.txtpeso.Name = "txtpeso";
            this.txtpeso.Size = new System.Drawing.Size(100, 26);
            this.txtpeso.TabIndex = 9;
            this.txtpeso.Validated += new System.EventHandler(this.txtpeso_Validated);
            // 
            // txtaltura
            // 
            this.txtaltura.Location = new System.Drawing.Point(299, 166);
            this.txtaltura.Name = "txtaltura";
            this.txtaltura.Size = new System.Drawing.Size(100, 26);
            this.txtaltura.TabIndex = 10;
            this.txtaltura.Validated += new System.EventHandler(this.txtaltura_Validated);
            // 
            // erropeso
            // 
            this.erropeso.ContainerControl = this;
            // 
            // erroaltura
            // 
            this.erroaltura.ContainerControl = this;
            // 
            // txtclassi
            // 
            this.txtclassi.Enabled = false;
            this.txtclassi.Location = new System.Drawing.Point(553, 166);
            this.txtclassi.Name = "txtclassi";
            this.txtclassi.Size = new System.Drawing.Size(100, 26);
            this.txtclassi.TabIndex = 14;
            // 
            // txtbeso
            // 
            this.txtbeso.Enabled = false;
            this.txtbeso.Location = new System.Drawing.Point(553, 215);
            this.txtbeso.Name = "txtbeso";
            this.txtbeso.Size = new System.Drawing.Size(100, 26);
            this.txtbeso.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(431, 215);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "obesidade";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(431, 166);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "classificação";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtclassi);
            this.Controls.Add(this.txtbeso);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtaltura);
            this.Controls.Add(this.txtpeso);
            this.Controls.Add(this.txtimc);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.btncalcular);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.erropeso)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erroaltura)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btncalcular;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnsair;
        private System.Windows.Forms.TextBox txtimc;
        private System.Windows.Forms.MaskedTextBox txtpeso;
        private System.Windows.Forms.MaskedTextBox txtaltura;
        private System.Windows.Forms.ErrorProvider erropeso;
        private System.Windows.Forms.ErrorProvider erroaltura;
        private System.Windows.Forms.MaskedTextBox txtclassi;
        private System.Windows.Forms.TextBox txtbeso;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

