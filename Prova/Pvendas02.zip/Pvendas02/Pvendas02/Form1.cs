﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvendas02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] vendas = new double[2, 4];
            string Dados;
            string mesum;
            for (int i = 1; i < 3; i++)
            {
                for (int j = 1; j < 5; j++)
                {
                    Dados = Interaction.InputBox($"digite o valor de vendas da semana{j + 1}", "Entrada de dados");
                   LsBx1.Items.Add($"total do mes {i} semana {j} {Dados}");
                    if (j == j + 4) ;
                    {
                        mesum = Dados;
                        LsBx1.Items.Add($"total do mes {mesum}");

                    }

                    
                    
                    
                }



                }
            }
            

        }
    }

