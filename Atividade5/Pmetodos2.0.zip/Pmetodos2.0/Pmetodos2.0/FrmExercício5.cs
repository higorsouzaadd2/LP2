﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos2._0
{
    public partial class FrmExercício5 : Form
    {
        public FrmExercício5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            // Validação dos números
            bool valido1 = int.TryParse(txtNumero1.Text, out int numero1);
            bool valido2 = int.TryParse(txtNumero2.Text, out int numero2);

            if (!valido1 || !valido2)
            {
                MessageBox.Show("Digite apenas números válidos.");
                return;
            }

            if (numero1 >= numero2)
            {
                MessageBox.Show("O primeiro número deve ser menor que o segundo.");
                return;
            }

            // Sorteio
            Random rnd = new Random();
            int sorteado = rnd.Next(numero1, numero2 + 1); // inclui o segundo número

            MessageBox.Show($"Número sorteado é: {sorteado}");
        }
    }

}
    

